package com.shatteredseals.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import org.lwjgl.glfw.GLFW;

public final class SkillTreeClient {
    public static final KeyMapping OPEN_SKILLS = new KeyMapping(
        "key.shatteredseals.open_skills", InputConstants.Type.KEYSYM,
        GLFW.GLFW_KEY_K, "key.categories.shatteredseals");

    @EventBusSubscriber(modid = "shatteredseals", value = Dist.CLIENT,
        bus = EventBusSubscriber.Bus.MOD)
    public static final class ModEvents {
        @SubscribeEvent
        public static void registerKeys(RegisterKeyMappingsEvent event) {
            event.register(OPEN_SKILLS);
        }
    }

    @EventBusSubscriber(modid = "shatteredseals", value = Dist.CLIENT)
    public static final class GameEvents {
        @SubscribeEvent
        public static void tick(ClientTickEvent.Post event) {
            Minecraft mc = Minecraft.getInstance();
            if (mc.player == null || mc.screen != null) return;
            while (OPEN_SKILLS.consumeClick()) mc.setScreen(new SkillTreeScreen());
        }
    }
    private SkillTreeClient() {}
}
