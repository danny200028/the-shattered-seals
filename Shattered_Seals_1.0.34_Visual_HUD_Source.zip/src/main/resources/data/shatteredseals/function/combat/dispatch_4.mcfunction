execute if score @s ss_path matches 1 run function shatteredseals:combat/vanguard_4
execute if score @s ss_path matches 2 run function shatteredseals:combat/warden_4
execute if score @s ss_path matches 3 run function shatteredseals:combat/pathfinder_4
execute if score @s ss_path matches 4 run function shatteredseals:combat/arcanist_4
