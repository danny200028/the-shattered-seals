execute if score @s ss_path matches 1 run function shatteredseals:combat/vanguard_2
execute if score @s ss_path matches 2 run function shatteredseals:combat/warden_2
execute if score @s ss_path matches 3 run function shatteredseals:combat/pathfinder_2
execute if score @s ss_path matches 4 run function shatteredseals:combat/arcanist_2
