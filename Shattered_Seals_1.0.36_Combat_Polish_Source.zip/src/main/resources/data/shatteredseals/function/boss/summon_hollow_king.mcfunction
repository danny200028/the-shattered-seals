execute positioned ^ ^ ^6 positioned over motion_blocking run summon minecraft:ravager ~ ~ ~ {Tags:["ss_boss","ss_hollow_king"],CustomName:'{"text":"Hollow King","color":"dark_red","bold":true}',CustomNameVisible:1b,PersistenceRequired:1b,Health:450.0f,DeathLootTable:"shatteredseals:boss/hollow_king",attributes:[{id:"minecraft:generic.max_health",base:450.0d},{id:"minecraft:generic.attack_damage",base:20.0d},{id:"minecraft:generic.movement_speed",base:0.31d}]}
execute positioned ^ ^ ^6 positioned over motion_blocking as @e[tag=ss_hollow_king,sort=nearest,limit=1,distance=..3] run attribute @s minecraft:generic.max_health base set 450
execute positioned ^ ^ ^6 positioned over motion_blocking as @e[tag=ss_hollow_king,sort=nearest,limit=1,distance=..3] run attribute @s minecraft:generic.attack_damage base set 20
execute positioned ^ ^ ^6 positioned over motion_blocking as @e[tag=ss_hollow_king,sort=nearest,limit=1,distance=..3] run attribute @s minecraft:generic.movement_speed base set 0.31
execute positioned ^ ^ ^6 positioned over motion_blocking as @e[tag=ss_hollow_king,sort=nearest,limit=1,distance=..3] run data merge entity @s {Health:450.0f}
# Reward fallback watcher: invisible marker attached to the new boss.
execute positioned ^ ^ ^6 positioned over motion_blocking as @e[tag=ss_hollow_king,tag=!ss_watch_linked,sort=nearest,limit=1,distance=..4] at @s run summon minecraft:marker ~ ~ ~ {Tags:["ss_boss_watch","ss_watch_hollow_king"]}
execute positioned ^ ^ ^6 positioned over motion_blocking as @e[tag=ss_hollow_king,tag=!ss_watch_linked,sort=nearest,limit=1,distance=..4] run tag @s add ss_watch_linked
function shatteredseals:boss/start_heartbeat
execute if score @s ss_ng matches 1.. at @s run effect give @e[tag=ss_hollow_king,distance=..10,sort=nearest,limit=1] minecraft:strength 99999 2 true
execute if score @s ss_ng matches 1.. at @s run effect give @e[tag=ss_hollow_king,distance=..10,sort=nearest,limit=1] minecraft:resistance 99999 0 true
tellraw @s {"text":"Hollow King has awakened. Prepare for three phases!","color":"dark_red","bold":true}
