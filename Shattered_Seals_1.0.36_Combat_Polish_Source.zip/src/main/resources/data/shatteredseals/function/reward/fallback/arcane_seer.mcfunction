# Run as a marker at the last observed boss location.
execute if entity @p[distance=..80,gamemode=!spectator] as @p[distance=..80,gamemode=!spectator] run function shatteredseals:reward/arcane_seer
