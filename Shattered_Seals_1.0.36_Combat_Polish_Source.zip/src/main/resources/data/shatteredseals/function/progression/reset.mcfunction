execute unless score @s ss_respec matches 1 run tellraw @s {"text":"To reset skills: /trigger ss_respec set 1 (consumes 1 Dragon Egg)","color":"yellow"}
execute if score @s ss_respec matches 1 run function shatteredseals:progression/reset_confirm
