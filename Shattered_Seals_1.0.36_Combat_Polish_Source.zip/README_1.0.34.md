# 1.0.34 Visual Combat HUD
Adds an on-screen 4-slot combat overlay above the vanilla hotbar.
Q/R/V/G, class-dependent ability names, server-synced cooldown countdowns (tenths of seconds),
and recharge overlays. Polls server snapshot every five client ticks, 4 times per second.

Important: Resource meters (Fury/Guard/Focus/Arcane Energy) are NOT shown yet:
the underlying gameplay resources do not exist in 1.0.33 and displaying a fake bar
would misrepresent the mechanics. Resource gameplay and bars are a later update.

Requires real NeoForge compilation and in-game HUD placement verification.
