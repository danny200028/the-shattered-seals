@echo off
setlocal
cd /d "%~dp0"
echo ============================================
echo THE SHATTERED SEALS 1.0.31 - NEOFORGE BUILD
 echo ============================================
echo.
echo Checking for JDK 21...
where javac >nul 2>nul
if errorlevel 1 (
  echo ERROR: Java JDK 21 is not on your PATH.
  echo Install JDK 21, reopen this folder, then try again.
  pause
  exit /b 1
)
java -version 2>java-version.txt
javac -version >>java-version.txt 2>&1
findstr /c:"javac 21" java-version.txt >nul
if errorlevel 1 (
  echo ERROR: This project requires JDK 21. Detected:
  type java-version.txt
  pause
  exit /b 1
)
set "GVER=8.14"
set "GRADLE_BAT=%~dp0.build-tools\gradle-%GVER%\bin\gradle.bat"
if not exist "%GRADLE_BAT%" (
  echo Downloading Gradle %GVER% from official Gradle distribution site...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $folder=Join-Path (Get-Location).Path '.build-tools'; New-Item -ItemType Directory -Force -Path $folder | Out-Null; $zip=Join-Path $folder 'gradle-8.14-bin.zip'; Invoke-WebRequest -Uri 'https://services.gradle.org/distributions/gradle-8.14-bin.zip' -OutFile $zip; Expand-Archive -LiteralPath $zip -DestinationPath $folder -Force"
  if errorlevel 1 (
    echo ERROR: Gradle download failed. Check your internet connection.
    pause
    exit /b 1
  )
)
echo.
echo Building against real NeoForge 1.21.1 dependencies...
echo This requires internet access and will download Minecraft and NeoForge artifacts.
call "%GRADLE_BAT%" build --stacktrace --console=plain > compile-log.txt 2>&1
if errorlevel 1 (
  echo.
  echo BUILD FAILED. Compiler details saved to compile-log.txt
  echo Last 50 lines of build log:
  powershell -NoProfile -Command "Get-Content -LiteralPath 'compile-log.txt' -Tail 50"
  pause
  exit /b 1
)
echo.
echo BUILD SUCCEEDED. Compiled JAR files are in build\libs\
dir /b build\libs\*.jar
 echo.
echo IMPORTANT: Test this build on a disposable world before using your main save.
pause
