# The Shattered Seals 1.0.36: Combat Polish & Balancing

- Replaced unreliable sprint NBT polling with vanilla sprint distance statistics for Pathfinder Focus.
- Guard and Fury still generate from damage taken/dealt statistics; negative deltas are discarded.
- Added resource-aware HUD indicators for unaffordable abilities.
- Removed duplicate actionbar cooldown warnings: native HUD displays countdowns.
- Added `/trigger ss_combat_test set 1` to show class, resources and cooldowns in-game.
- Preserved all four classes, 16 abilities, skill GUI, resource bars and existing cooldowns.
- This is a prototype. No real Minecraft runtime tests yet; build and in-game validation required.
