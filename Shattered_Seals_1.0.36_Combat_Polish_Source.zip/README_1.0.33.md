# 1.0.33 Four-slot combat abilities (prototype)
Minecraft Java 1.21.1 NeoForge, Java 21.

Controls: K = skill tree; Q = slot 1; R = slot 2; V = slot 3; G = slot 4.
Each of four classes has four unique active effects (16 abilities total).
Slot 1 retained from 1.0.32; slots 2–4 use independent server-enforced cooldown objectives.
All slot 2–4 combat targeting uses the existing combat_targets entity-type tag.
This is NOT the graphical ability hotbar or resource-meter system yet.
Build and runtime verification pending. In-game validation required, especially combat targeting and key conflicts.
