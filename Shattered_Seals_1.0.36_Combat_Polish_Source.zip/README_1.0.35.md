# The Shattered Seals 1.0.35: Class Resources
Server-authoritative, persistent Fury/Guard/Focus/Arcane resource scoreboards (0–100).
Each class retains its own resource when switching. All start at 100.
Regen per second: Fury 2, Guard 4, Focus 5, Arcane 8.
Fury +8 from damage dealt; Guard +10 from damage taken; Focus +3 from sprinting on the 1-second tick.
Costs by ability slot Q/R/V/G: 12/20/28/45. Cooldowns are still separate.
Insufficient resources block casting, with actionbar feedback.
Client snapshot includes all four resources and HUD renders a real resource bar.

NOTE: This is an initial balance model, not tested in-game. Sprint detection,
damage-stat objectives, actionbar conflicts and resource cap behavior require testing.
