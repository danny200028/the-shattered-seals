# The Shattered Seals 1.0.31 — GitHub Actions build instructions

**Status: build-ready source, not a verified JAR.** GitHub Actions will attempt a real compilation using Java 21, Gradle 8.14 and official NeoForge 21.1.238. The workflow has not been run by ChatGPT, and source compatibility remains unverified until GitHub finishes the build.

## Using the ChatGPT GitHub connection
Connect the GitHub app in ChatGPT, then ask ChatGPT to create a repository for `The Shattered Seals` and upload the files from this ZIP, preserving the `.github/workflows/build.yml` path. This requires your permission to access your GitHub account and support for repository writes and workflow runs. Depending on app capabilities, you might need to approve an upload or trigger a build yourself.

## GitHub web UI (without a ChatGPT connection)
1. Sign in to GitHub and make a new empty repository (private is fine).
2. Extract this ZIP locally and upload **all of its contents**, not the ZIP file itself. The hidden `.github` directory must be included as `.github/workflows/build.yml`.
3. Commit directly to the repository's default branch. The `push` trigger will start a build. If no build appears, use the repository **Actions** tab → **Build The Shattered Seals 1.0.31** → **Run workflow**.
4. Wait for the result in GitHub. On **success**, download the artifact `Shattered-Seals-1.0.31-NeoForge-JAR`. On **failure**, download `Shattered-Seals-1.0.31-Build-Log` or copy the failed step's error lines and send them to ChatGPT for fixes.
5. A successful compilation is not equivalent to an in-game test. Install the compiled JAR in a disposable Minecraft Java 1.21.1 NeoForge world first, with backups, and remove the old Shattered Seals JAR. Do not install both versions.

### What the workflow actually checks
- Static JSON and scoreboard-resource preflight.
- Real NeoForge Java compilation and JAR packaging.
- SHA256 hashes, build log and build artifact.

### What it does not check
- Launching Minecraft or gameplay correctness.
- Worldgen safety or compatibility with other mods.
- That all Java source APIs are valid in the targeted NeoForge version (compile will flag mismatches).

**No credentials or tokens are bundled in this project.**
