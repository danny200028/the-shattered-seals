# The Shattered Seals 1.0.31 | Integrated NeoForge GUI source

**Status: UNCOMPILED development source. This is NOT an installable release.**

### What's here
This source contains all of the assets, data-driven RPG systems, loot, bosses and textures copied from the actual 1.0.30 JAR, plus the NeoForge graphical skill tree source and networking code. It fixes issues in the earlier GUI-only prototype:

- The project now targets NeoForge **21.1.238**, matching the current existing mod's minimum dependency (not the obsolete 21.1.219).
- Correct server trigger commands: `ss_buy` (1–4 core), `ss_branch` (1–12 ranks), `ss_ascend` (1–12 mastery), `ss_switch` (1–4 classes), `ss_respec` (Dragon Egg).
- Server-authoritative snapshot network packets keep level, XP, kill count, skill points, 12 ranks, 12 mastery flags and active class accurate. Vanilla undisplayed scoreboard scores are not reliably synced to clients.
- Preserves skill upgrades when changing classes. Dragon Egg reset still consumes one egg on the server, subject to the existing progression functions.
- Keeps original 1.0.30 resources in one mod rather than distributing two JARs with the same mod ID.
- Provides a K key binding and native `Screen` buttons, not a chat menu.

### Compile (requires internet and Java 21)
Use Gradle 8.14+ and run `gradle build`. The installed JAR, *if compilation succeeds*, will be in `build/libs/`. The GitHub Actions workflow can also compile automatically after pushing this project to a repository. The workflow has **not** been run.

### Remaining risks and limitations
- This environment could not resolve NeoForge or Gradle repositories: it has Java 21 but **no Gradle installation or NeoForge/Minecraft compilation dependencies**. Thus code is not compiled or tested against the real NeoForge APIs; method signatures, event bus annotations, registration and network handlers may need fixes.
- The original 1.0.30 mod's datapack functions and worldgen were not tested in a live game here. This project faithfully carries them forward, including any preexisting issues.
- No confirmation of in-game results. Do not install generated source as a mod. Make a world backup and test on a separate Creative save after compilation.
- The `Balance` class retained from the earlier code base is informational; numeric constants should be audited if future code depends on them.
- In-game test plan: keybind opens Screen; server snapshot loads; levels/XP/SP/kills display; buy core talent, branches and mastery correctly; switching classes leaves purchased ranks intact; Dragon Egg reset consumes exactly one egg; previous boss/relic/HUD functions survive.
