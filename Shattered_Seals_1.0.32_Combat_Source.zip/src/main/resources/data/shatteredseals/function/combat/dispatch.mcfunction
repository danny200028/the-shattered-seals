# One ability per active class. Server selects class and enforces cooldown.
execute if score @s ss_path matches 1 run function shatteredseals:combat/vanguard
execute if score @s ss_path matches 2 run function shatteredseals:combat/warden
execute if score @s ss_path matches 3 run function shatteredseals:combat/pathfinder
execute if score @s ss_path matches 4 run function shatteredseals:combat/arcanist
