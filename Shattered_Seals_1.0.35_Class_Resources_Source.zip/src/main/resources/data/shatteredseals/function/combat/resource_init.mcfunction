scoreboard players set @s ss_fury 100
scoreboard players set @s ss_guard 100
scoreboard players set @s ss_focus 100
scoreboard players set @s ss_arcane 100
scoreboard players operation @s ss_damage_prev = @s ss_damage_now
scoreboard players operation @s ss_taken_prev = @s ss_taken_now
scoreboard players set @s ss_resinit 1
